package com.isep.components;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProposalTest {
    @Test
    public void testProposal(){
        Proposal prop = new Proposal(new Player(),0);
        prop.setProposal(45);
        assertEquals(45,prop.getProposal());
    }
}
