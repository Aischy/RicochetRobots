package com.isep.components;

import javafx.scene.image.Image;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class RobotTest {
    @Test
    public void testRow(){
        Image image = null;
        Robot robot = new Robot("purple",image,1,1,image);
        robot.setRow(5);
        assertEquals(5,robot.getRow());
    }
}
