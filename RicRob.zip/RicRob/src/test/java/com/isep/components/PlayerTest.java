package com.isep.components;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PlayerTest {
    @Test
    public void testNbWinTarget(){
        Player player = new Player();
        player.setNbWinTarget(46);
        assertEquals(46,player.getNbWinTarget());
    }
}
