package com.isep.components;

import javafx.scene.image.Image;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TargetTest {
    @Test
    public void testRow(){
        Image image = null;
        Target target = new Target("purple",3,1,1,image);
        target.setRow(5);
        assertEquals(5,target.getRow());
    }
}
