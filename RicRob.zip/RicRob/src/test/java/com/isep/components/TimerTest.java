package com.isep.components;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TimerTest {
    @Test
    public void testTrigger(){
        Timer timer = new Timer();
        timer.setTrigger(true);
        assertEquals(true,timer.getTrigger());
    }
}
