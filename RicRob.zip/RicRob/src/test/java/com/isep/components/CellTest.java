package com.isep.components;

import javafx.scene.image.Image;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CellTest {
    @Test
    public void testOccupationRobot(){
        Image image = null;
        Cell cell = new Cell(0,0,0,image);
        cell.setOccRobot(true);
        assertEquals(true,cell.getOccRobot());
    }
}