package com.isep.components;

import javafx.scene.image.Image;

public class Robot {

    //Attributes
    private String color;
    private Image robotTokenImage;
    private int row;
    private int column;

    private int startRow;
    private int startColumn;
    private Image startPosTokenImage;


    //Constructor
    public Robot(String color, Image robotToken, int startRow, int startColumn, Image startToken){
        this.color=color;
        this.robotTokenImage=robotToken;
        this.row=startRow;
        this.column=startColumn;

        this.startRow=startRow;
        this.startColumn=startColumn;
        this.startPosTokenImage=startToken;
    }

    //Methods
    public String getColor(){return color;}
    public Image getRobotToken(){return robotTokenImage;}
    public int getRow(){return row;}
    public int getCol(){return column;}

    public int getRowStart(){return startRow;}
    public int getColStart(){return startColumn;}
    public Image getStartToken(){return startPosTokenImage;}


    public void setRow(int row){
        this.row=row;
    }

    public void setCol(int col){
        this.column=col;
    }

    public void setStartRow(int row){
        this.startRow=row;
    }

    public void setStartCol(int col){
        this.startColumn=col;
    }

    //Methods to move the robots

    public void goToRight(Cell[][] listCells) {
        int iniCol = this.column;
        int newColumn = this.column;
        int row = this.row;
        boolean stop = false;

        while(stop != true){
            int typeCase = listCells[row][newColumn].getType();
            boolean occRobCase = listCells[row][newColumn].getOccRobot();
            if((typeCase == 3  && newColumn!=iniCol)|| typeCase == 6 || occRobCase == true){
                newColumn--;
                stop = true;
            }else  if(newColumn == 15 || typeCase == 2) {
                stop = true;
            }else{
                newColumn++;
            }
        }
        this.column=newColumn;
    }

    public void goToLeft(Cell[][] listCells) {
        int iniCol = this.column;
        int newColumn = this.column;
        int row = this.row;
        boolean stop = false;

        while(stop != true){
            int typeCase = listCells[row][newColumn].getType();
            boolean occRobCase = listCells[row][newColumn].getOccRobot();
            if((typeCase == 2 && newColumn!=iniCol)|| typeCase == 6 || occRobCase == true){
                newColumn++;
                stop = true;
            }else  if(newColumn == 0 || typeCase == 3) {
                stop = true;
            }else{
                newColumn--;
            }
        }
        this.column=newColumn;
    }

    public void goToDown(Cell[][] listCells) {
        int iniRow = this.row;
        int column = this.column;
        int newRow = this.row;
        boolean stop = false;

        while(stop != true){
            int typeCase = listCells[newRow][column].getType();
            boolean occRobCase = listCells[newRow][column].getOccRobot();
            if((typeCase == 4 && newRow!=iniRow) || typeCase == 6 || occRobCase == true){
                newRow--;
                stop = true;
            }else  if(newRow == 15 || typeCase == 5) {
                stop = true;
            }else{
                newRow++;
            }
        }
        this.row=newRow;
    }

    public void goToUp(Cell[][] listCells) {
        int iniRow = this.row;
        int column = this.column;
        int newRow = this.row;
        boolean stop = false;

        while(stop != true){
            int typeCase = listCells[newRow][column].getType();
            boolean occRobCase = listCells[newRow][column].getOccRobot();
            if((typeCase == 5 && newRow!=iniRow) || typeCase == 6 || occRobCase == true){
                newRow++;
                stop = true;
            }else  if(newRow == 0 || typeCase == 4) {
                stop = true;
            }else{
                newRow--;
            }
        }
        this.row=newRow;
    }



}
