package com.isep.components;

public class Timer {
    //Attributes
    int time; //Time before the end
    boolean trigger; //Has the timer been triggered?

    //Constructor
    public Timer(){
        this.time = 10;
        this.trigger = false;
    }

    //Methods
    public int getTime(){return time;}
    public boolean getTrigger(){return trigger;}

    public void setTime(int time){
        this.time=time;
    }

    public void setTrigger(boolean trigger){
        this.trigger=trigger;
    }

    public void initialize(){
        this.time = 10;
        this.trigger = false;
    }
}
