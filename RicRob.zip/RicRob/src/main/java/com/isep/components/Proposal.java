package com.isep.components;

public class Proposal {

    //Attributes
    Player player;
    int proposal;

    //Constructor
    public Proposal(Player player,int prop){
        this.player=player;
        this.proposal = prop;
    }

    //Methods
    public Player getPlayer(){return player;}
    public int getProposal(){return proposal;}

    public void setPlayer(Player player){
        this.player=player;
    }
    public void setProposal(int proposal) {
        this.proposal = proposal;
    }
}
