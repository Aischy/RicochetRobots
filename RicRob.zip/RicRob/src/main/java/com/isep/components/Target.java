package com.isep.components;

import javafx.scene.image.Image;

public class Target {

    //Attributes
    private String color;
    private int idTarget; //1 to 4 for each color + 5 for multicolor
    private int row;
    private int column;
    private Image image;

    //Constructor
    public Target(String color, int idToken, int row, int column, Image image){
        this.color=color;
        this.idTarget=idToken;
        this.row=row;
        this.column=column;
        this.image=image;
    }

    //Methods
    public String getColor(){return color;}
    public int getIdTarget(){return idTarget;}
    public int getRow(){return row;}
    public int getColumn(){return column;}
    public Image getImage(){return image;}

    public String setColor(String color){
        this.color=color;
        return color;
    }

    public int setRow(int row){
        this.row=row;
        return row;
    }
    public int setCol(int col){
        this.column=col;
        return col;
    }
    public Image getImage(Image image){
        this.image=image;
        return image;
    }

}
