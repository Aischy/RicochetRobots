package com.isep.components;


import javafx.scene.Node;
import javafx.scene.image.Image;

public class Cell {

    //Attributes
    private int row;
    private int column;
    private boolean occRobot; //occ=occupation, true if a robot is on the cell
    private boolean occTarget; //true if an objective is on the cell
    private boolean occStartToken; //true if a start token of a robot is on the cell
    private int type;
    private Image image;

    /*The different types of cells :
        0 = Normal classic cell
        1 = target cell
        2 = Cell with barrier facing right
        3 = Cell with barrier facing left
        4 = Cell with barrier facing up
        5 = Cell with barrier facing down
        6 = Cell of the central block
    */

    //Constructor
    public Cell(int row, int column, int type, Image image){
        this.row=row;
        this.column=column;
        this.occRobot=false;
        this.occTarget=false;
        this.occStartToken=false;
        this.type=type;
        this.image=image;
    }

    //Functions get data
    public int getRow(){return row;}
    public int getCol(){return column;}
    public boolean getOccRobot(){return occRobot;}
    public boolean getOccTarget(){return occTarget;}
    public boolean getOccStartToken(){return occStartToken;}
    public int getType(){return type;}
    public Image getImage(){return image;}


    //Function set data
    public int setRow(int row){
        this.row=row;
        return row;
    }

    public int setCol(int col){
        this.column=col;
        return col;
    }

    public boolean setOccRobot(boolean occ){
        this.occRobot=occ;
        return occRobot;
    }

    public boolean setOccTarget(boolean occ){
        this.occTarget=occ;
        return occTarget;
    }

    public boolean setOccStartToken(boolean occ){
        this.occStartToken=occ;
        return occStartToken;
    }

    public int setType(int type) {
        this.type=type;
        return type;
    }

    public Image setImage(Image image){
        this.image=image;
        return image;
    }

}
