package com.isep.components;

public class Player {

    //Attributes
    private int nbWinTarget;

    //Constructor
    public Player(){
        this.nbWinTarget=0;
    }

    public int getNbWinTarget(){return nbWinTarget;}

    public void setNbWinTarget(int nbWinTarget) {
        this.nbWinTarget = nbWinTarget;
    }
}
