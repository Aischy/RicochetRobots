package com.isep.ricrob;

import com.isep.components.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

import java.util.ArrayList;
import java.util.Random;

public class MainController {
    @FXML
    GridPane robotBoard;
    static int TILE_SIZE = 36;
    static Cell[][] listCells = new Cell[16][16];
    static Target[] listTargets = new Target[17];
    static Robot blueRobot;
    static Robot greenRobot;
    static Robot redRobot;
    static Robot yellowRobot;
    static Robot[] listRobots = new Robot[4];
    static ArrayList<String> colors = new ArrayList<String>();
    static Random r = new Random();


    // "initialize()" est appelé par JavaFX à l'affichage de la fenêtre

    @FXML
    public void initialize() {
        colors.add("blue");
        colors.add("green");
        colors.add("red");
        colors.add("yellow");
        colors.add("multicolor");

        //Images for each type of cell
        Image image0 = new Image("cell0.png", TILE_SIZE, TILE_SIZE, false, true);
        Image image2 = new Image("cell2.png", TILE_SIZE, TILE_SIZE, false, true);
        Image image3 = new Image("cell3.png", TILE_SIZE, TILE_SIZE, false, true);
        Image image4 = new Image("cell4.png", TILE_SIZE, TILE_SIZE, false, true);
        Image image5 = new Image("cell5.png", TILE_SIZE, TILE_SIZE, false, true);
        Image image6 = new Image("cell6.png", TILE_SIZE, TILE_SIZE, false, true);

        //Construction of the blank tray and the Cell objects
        int gameSize = 16;
        for (int row = 0; row < gameSize; row++) {
            for (int col = 0; col < gameSize; col++) {
                listCells[row][col]=new Cell(row,col,1,image0);
            }
        }

        //Construction of the case of type 6
        for(int i=7;i<9;i++){
            for(int j=7;j<9;j++){
                listCells[i][j].setImage(image6);
                listCells[i][j].setType(6);
            }
        }

        //Construction of the case in the board with an orthogonal wall
        int lig1 = r.nextInt(3)+2;
        int type1 = r.nextInt(1);
        if(type1==0){
            listCells[lig1][0].setType(4);
            listCells[lig1][0].setImage(image4);
        }else{
            listCells[lig1][0].setType(5);
            listCells[lig1][0].setImage(image5);
        }

        int lig2 = r.nextInt(3)+2;
        int type2 = r.nextInt(1);
        if(type2==0){
            listCells[lig2][15].setType(4);
            listCells[lig2][15].setImage(image4);
        }else{
            listCells[lig2][15].setType(5);
            listCells[lig2][15].setImage(image5);
        }

        int lig3 = r.nextInt(3)+10;
        int type3 = r.nextInt(1);
        if(type3==0){
            listCells[lig3][0].setType(4);
            listCells[lig3][0].setImage(image4);
        }else{
            listCells[lig3][0].setType(5);
            listCells[lig3][0].setImage(image5);
        }

        int lig4 = r.nextInt(3)+10;
        int type4 = r.nextInt(1);
        if(type4==0){
            listCells[lig4][15].setType(4);
            listCells[lig4][15].setImage(image4);
        }else{
            listCells[lig4][15].setType(5);
            listCells[lig4][15].setImage(image5);
        }

        int col1 = r.nextInt(3)+2;
        int type11 = r.nextInt(1);
        if(type11==0){
            listCells[0][col1].setType(2);
            listCells[0][col1].setImage(image2);
        }else{
            listCells[0][col1].setType(3);
            listCells[0][col1].setImage(image3);
        }

        int col2 = r.nextInt(3)+2;
        int type12 = r.nextInt(1);
        if(type12==0){
            listCells[15][col2].setType(2);
            listCells[15][col2].setImage(image2);
        }else{
            listCells[15][col2].setType(3);
            listCells[15][col2].setImage(image3);
        }

        int col3 = r.nextInt(3)+10;
        int type13 = r.nextInt(1);
        if(type13==0){
            listCells[0][col3].setType(2);
            listCells[0][col3].setImage(image2);
        }else{
            listCells[0][col3].setType(3);
            listCells[0][col3].setImage(image3);
        }

        int col4 = r.nextInt(3)+10;
        int type14 = r.nextInt(1);
        if(type14==0){
            listCells[15][col4].setType(2);
            listCells[15][col4].setImage(image2);
        }else{
            listCells[15][col4].setType(3);
            listCells[15][col4].setImage(image3);
        }

        //Placement of targets and construction of walls next to them

        //Create list of possible cases for target
        ArrayList<Integer> targetCases = new ArrayList<Integer>();
        for(int i = 0; i<16*16;i++){
            if(i>32 && i<223 && i%16!=0 && i%16!=15 && i%16!=1 && i%16!=14){
                if (!((i>101 && i<106)||(i>117 && i<122)||(i>133 && i<138)||(i>149 && i<154))) {
                    targetCases.add(i);
                }
            }
        }

        //Creation of the targets
        int target=0;
        for(int color=0;color<colors.size();color++){
            for(int index=1;index<5;index++){
                if(colors.get(color).equalsIgnoreCase("multicolor")){
                    index=5;
                }
                //Creation of the target
                String imageNameTarget = colors.get(color)+"_target_"+index+".png";
                String imageNameCell = "cell1_"+colors.get(color)+index+".png";
                Image imageTarget = new Image(imageNameTarget, TILE_SIZE, TILE_SIZE, false, true);
                Image imageCell = new Image(imageNameCell, TILE_SIZE, TILE_SIZE, false, true);


                //Placement of the target
                int randomIndex = r.nextInt(targetCases.size());
                int caseTarget = targetCases.get(randomIndex);
                int colTarget = caseTarget%16;
                int rowTarget = (caseTarget-colTarget)/16;
                listTargets[target] = new Target(colors.get(color),index,rowTarget,colTarget,imageTarget);

                //Remove the new target cell and the 9-square cells around of the list of possibles cells for target
                for(int i=0;i<3;i++){
                    for(int j=0;j<3;j++){
                        int kValue = (caseTarget-17)+i*16+j;
                        for(int kIndex=0; kIndex<targetCases.size(); kIndex++)
                            if(targetCases.get(kIndex)==kValue){
                                targetCases.remove(kIndex);
                        }
                    }
                }

                //Create tiles of the target and the cases wall around
                listCells[rowTarget][colTarget].setImage(imageCell);
                listCells[rowTarget][colTarget].setType(2);
                listCells[rowTarget][colTarget].setOccTarget(true);

                    //Wall right or left
                int rl = r.nextInt(2);
                if(rl==0){
                    listCells[rowTarget+1][colTarget].setImage(image4);
                    listCells[rowTarget+1][colTarget].setType(4);
                }else{
                    listCells[rowTarget-1][colTarget].setImage(image5);
                    listCells[rowTarget-1][colTarget].setType(5);
                }


                    //Wall up or down
                int ud = r.nextInt(2);
                if(ud==0){
                    listCells[rowTarget][colTarget-1].setImage(image2);
                    listCells[rowTarget][colTarget-1].setType(2);
                }else{
                    listCells[rowTarget][colTarget+1].setImage(image3);
                    listCells[rowTarget][colTarget+1].setType(3);
                }
                target++;
            }
        }
        //Multicolor target

        //Display of the board
        for (int row = 0; row < gameSize; row++) {
            for (int col = 0; col < gameSize; col++) {
                ImageView tileGui = new ImageView(listCells[row][col].getImage());
                robotBoard.add(tileGui,listCells[row][col].getCol(),listCells[row][col].getRow());
            }
        }

        //Creation of the robots
        Image blueRobotImage = new Image("blue_robot.png", TILE_SIZE, TILE_SIZE, false, true);
        Image blueRobotStart = new Image("blue_start.png", TILE_SIZE*0.8, TILE_SIZE*0.8, false, true);
        Image greenRobotImage = new Image("green_robot.png", TILE_SIZE, TILE_SIZE, false, true);
        Image greenRobotStart = new Image("green_start.png", TILE_SIZE*0.8, TILE_SIZE*0.8, false, true);
        Image redRobotImage = new Image("red_robot.png", TILE_SIZE, TILE_SIZE, false, true);
        Image redRobotStart = new Image("red_start.png", TILE_SIZE*0.8, TILE_SIZE*0.8, false, true);
        Image yellowRobotImage = new Image("yellow_robot.png", TILE_SIZE, TILE_SIZE, false, true);
        Image yellowRobotStart = new Image("yellow_start.png", TILE_SIZE*0.8, TILE_SIZE*0.8, false, true);

        int ligB=-1;
        int colB=-1;
        int ligG=-1;
        int colG=-1;
        int ligR=-1;
        int colR=-1;
        int ligY=-1;
        int colY=-1;
        do {
            ligB = r.nextInt(16);
            colB = r.nextInt(16);
        }while(ligB==7 || ligB==8 || colB==7 || colB==8 || listCells[ligB][colB].getOccTarget()==true);
        do {
            ligG = r.nextInt(16);
            colG = r.nextInt(16);
        }while(ligG==7 || ligG==8 || colG==7 || colG==8 || (ligG==ligB && colG==colB) || listCells[ligG][colG].getOccTarget()==true);
        do {
            ligR = r.nextInt(16);
            colR = r.nextInt(16);
        }while(ligR==7 || ligR==8 || colR==7 || colR==8 || (ligR==ligB && colR==colB) || (ligR==ligG && colR==colG) || listCells[ligR][colR].getOccTarget()==true);
        do {
            ligY = r.nextInt(16);
            colY = r.nextInt(16);
        }while(ligY==7 || ligY==8 || colY==7 || colY==8 || (ligY==ligB && colY==colB) || (ligY==ligG && colY==colG) || (ligY==ligR && colY==colR) || listCells[ligY][colY].getOccTarget()==true);

        blueRobot = new Robot("blue",blueRobotImage,ligB,colB,blueRobotStart);
        greenRobot = new Robot("green",greenRobotImage,ligG,colG,greenRobotStart);
        redRobot = new Robot("red",redRobotImage,ligR,colR,redRobotStart);
        yellowRobot = new Robot("yellow",yellowRobotImage,ligY,colY,yellowRobotStart);

        listRobots[0]=blueRobot;
        listRobots[1]=greenRobot;
        listRobots[2]=redRobot;
        listRobots[3]=yellowRobot;


        //Declaration of the robot occupation on the cells
        listCells[ligB][colB].setOccRobot(true);
        listCells[ligG][colG].setOccRobot(true);
        listCells[ligR][colR].setOccRobot(true);
        listCells[ligY][colY].setOccRobot(true);

        //Declaration of the robot start token occupation on the cells
        listCells[ligB][colB].setOccStartToken(true);
        listCells[ligG][colG].setOccStartToken(true);
        listCells[ligR][colR].setOccStartToken(true);
        listCells[ligY][colY].setOccStartToken(true);

        //Display of the robots
        robotBoard.add(new ImageView(blueRobot.getStartToken()), blueRobot.getColStart(), blueRobot.getRowStart());
        robotBoard.add(new ImageView(blueRobot.getRobotToken()), blueRobot.getCol(), blueRobot.getRow());
        robotBoard.add(new ImageView(greenRobot.getStartToken()), greenRobot.getColStart(), greenRobot.getRowStart());
        robotBoard.add(new ImageView(greenRobot.getRobotToken()), greenRobot.getCol(), greenRobot.getRow());
        robotBoard.add(new ImageView(redRobot.getStartToken()), redRobot.getColStart(), redRobot.getRowStart());
        robotBoard.add(new ImageView(redRobot.getRobotToken()), redRobot.getCol(), redRobot.getRow());
        robotBoard.add(new ImageView(yellowRobot.getStartToken()), yellowRobot.getColStart(), yellowRobot.getRowStart());
        robotBoard.add(new ImageView(yellowRobot.getRobotToken()), yellowRobot.getCol(), yellowRobot.getRow());

    }


    //Game
    @FXML
    static Timer timer = new Timer();
    @FXML
    private static ImageView actualTarget;
    static int propP1;
    static Player player1 = new Player();
    static Player player2 = new Player();
    static int propP2;
    static Proposal[] listProp = new Proposal[2]; //Used to know the order of the players after
    static int nbMovements = 0;

    /*protected static void game() { //Normalement c'est la fonction qui permet de tout faire fonctionner. Elle doit remplacer launch(); dans MainApplication
        /*int scoreJ1 = 0;
        int scoreJ2 = 0;
        int round = 0;
        while(listTargets.length != 0){
            int x = r.nextInt(listTargets.length);
            actualTarget= new ImageView(listTargets[x].getImage());
            Proposal[] newListProp = new Proposal[2];
            listProp = newListProp;
            timer.initialize();
            round++;
            if(timer.getTrigger()==true && timer.getTime()==0){
                nbMovements = 0;

            }
        }
    }*/

    //Buttons
    //Check proposal of players
    @FXML
    private TextField proposalP1;
    public void checkPropP1 (ActionEvent actionEvent){
        propP1 = Integer.valueOf(proposalP1.getText());

        if(timer.getTrigger()==false){
            timer.setTrigger(true);
            listProp[0]= new Proposal(player1,propP1);
        }else{
            if(propP1<listProp[0].getProposal() && listProp[0].getPlayer()==player2){
                listProp[1]=listProp[0];
                listProp[0]=new Proposal(player1,propP1);
            }else if(propP1>listProp[0].getProposal() && listProp[0].getPlayer()==player2 && propP1<listProp[1].getProposal()){
                listProp[1]=new Proposal(player1,propP1);
            }else if(propP1<listProp[0].getProposal() && listProp[0].getPlayer()==player1){
                listProp[0]=new Proposal(player1,propP1);
            }
        }
    }
    @FXML
    private TextField proposalP2;
    public void checkPropP2 (ActionEvent actionEvent){
        propP2 = Integer.valueOf(proposalP2.getText());

        if(timer.getTrigger()==false){
            timer.setTrigger(true);
            listProp[0]= new Proposal(player2,propP2);
        }else if(timer.getTime()>0){
            if(propP2<listProp[0].getProposal() && listProp[0].getPlayer()==player1){
                listProp[1]=listProp[0];
                listProp[0]=new Proposal(player2,propP2);
            }else if(propP2>listProp[0].getProposal() && listProp[0].getPlayer()==player1 && propP2<listProp[1].getProposal()){
                listProp[1]=new Proposal(player2,propP2);
            }else if(propP2<listProp[0].getProposal() && listProp[0].getPlayer()==player2){
                listProp[0]=new Proposal(player2,propP2);
            }
        }
    }



    //Arrows, move robots
    public void changeImageMove ( int row, int col){
        Image backgroundImage = null;
        if (listCells[row][col].getOccTarget() == true) {
            for (int i = 0; i < listTargets.length; i++) {
                if (listTargets[i].getRow() == row && listTargets[i].getColumn() == col) {
                    backgroundImage = listTargets[i].getImage();
                }
            }
        } else {
            backgroundImage = listCells[row][col].getImage();
        }
        robotBoard.add(new ImageView(backgroundImage), col, row);

        if (listCells[row][col].getOccStartToken() == true) {
            for (int i = 0; i < 4; i++) {
                if (listRobots[i].getRow() == row && listRobots[i].getCol() == col) {
                    robotBoard.add(new ImageView(listRobots[i].getStartToken()), col, row);
                }
            }

        }
    }

    //Red Robot
    public void redRightArrow (ActionEvent actionEvent){
        changeImageMove(redRobot.getRow(), redRobot.getCol());
        listCells[redRobot.getRow()][redRobot.getCol()].setOccRobot(false);
        redRobot.goToRight(listCells);
        robotBoard.add(new ImageView(redRobot.getRobotToken()), redRobot.getCol(), redRobot.getRow());
        listCells[redRobot.getRow()][redRobot.getCol()].setOccRobot(true);
    }
    public void redLeftArrow (ActionEvent actionEvent){
        changeImageMove(redRobot.getRow(), redRobot.getCol());
        listCells[redRobot.getRow()][redRobot.getCol()].setOccRobot(false);
        redRobot.goToLeft(listCells);
        robotBoard.add(new ImageView(redRobot.getRobotToken()), redRobot.getCol(), redRobot.getRow());
        listCells[redRobot.getRow()][redRobot.getCol()].setOccRobot(true);
    }
    public void redUpArrow (ActionEvent actionEvent){
        changeImageMove(redRobot.getRow(), redRobot.getCol());
        listCells[redRobot.getRow()][redRobot.getCol()].setOccRobot(false);
        redRobot.goToUp(listCells);
        robotBoard.add(new ImageView(redRobot.getRobotToken()), redRobot.getCol(), redRobot.getRow());
        listCells[redRobot.getRow()][redRobot.getCol()].setOccRobot(true);
    }
    public void redDownArrow (ActionEvent actionEvent){
        changeImageMove(redRobot.getRow(), redRobot.getCol());
        listCells[redRobot.getRow()][redRobot.getCol()].setOccRobot(false);
        redRobot.goToDown(listCells);
        robotBoard.add(new ImageView(redRobot.getRobotToken()), redRobot.getCol(), redRobot.getRow());
        listCells[redRobot.getRow()][redRobot.getCol()].setOccRobot(true);
    }


    //Blue Robot
    public void blueRightArrow (ActionEvent actionEvent){
        changeImageMove(blueRobot.getRow(), blueRobot.getCol());
        listCells[blueRobot.getRow()][blueRobot.getCol()].setOccRobot(false);
        blueRobot.goToRight(listCells);
        robotBoard.add(new ImageView(blueRobot.getRobotToken()), blueRobot.getCol(), blueRobot.getRow());
        listCells[blueRobot.getRow()][blueRobot.getCol()].setOccRobot(true);
    }
    public void blueLeftArrow (ActionEvent actionEvent){
        changeImageMove(blueRobot.getRow(), blueRobot.getCol());
        listCells[blueRobot.getRow()][blueRobot.getCol()].setOccRobot(false);
        blueRobot.goToLeft(listCells);
        robotBoard.add(new ImageView(blueRobot.getRobotToken()), blueRobot.getCol(), blueRobot.getRow());
        listCells[blueRobot.getRow()][blueRobot.getCol()].setOccRobot(true);
    }
    public void blueUpArrow (ActionEvent actionEvent){
        changeImageMove(blueRobot.getRow(), blueRobot.getCol());
        listCells[blueRobot.getRow()][blueRobot.getCol()].setOccRobot(false);
        blueRobot.goToUp(listCells);
        robotBoard.add(new ImageView(blueRobot.getRobotToken()), blueRobot.getCol(), blueRobot.getRow());
        listCells[blueRobot.getRow()][blueRobot.getCol()].setOccRobot(true);
    }
    public void blueDownArrow (ActionEvent actionEvent){
        changeImageMove(blueRobot.getRow(), blueRobot.getCol());
        listCells[blueRobot.getRow()][blueRobot.getCol()].setOccRobot(false);
        blueRobot.goToDown(listCells);
        robotBoard.add(new ImageView(blueRobot.getRobotToken()), blueRobot.getCol(), blueRobot.getRow());
        listCells[blueRobot.getRow()][blueRobot.getCol()].setOccRobot(true);
    }


    //Green Robot
    public void greenRightArrow (ActionEvent actionEvent){
        changeImageMove(greenRobot.getRow(), greenRobot.getCol());
        listCells[greenRobot.getRow()][greenRobot.getCol()].setOccRobot(false);
        greenRobot.goToRight(listCells);
        robotBoard.add(new ImageView(greenRobot.getRobotToken()), greenRobot.getCol(), greenRobot.getRow());
        listCells[greenRobot.getRow()][greenRobot.getCol()].setOccRobot(true);
    }
    public void greenLeftArrow (ActionEvent actionEvent){
        changeImageMove(greenRobot.getRow(), greenRobot.getCol());
        listCells[greenRobot.getRow()][greenRobot.getCol()].setOccRobot(false);
        greenRobot.goToLeft(listCells);
        robotBoard.add(new ImageView(greenRobot.getRobotToken()), greenRobot.getCol(), greenRobot.getRow());
        listCells[greenRobot.getRow()][greenRobot.getCol()].setOccRobot(true);
    }
    public void greenUpArrow (ActionEvent actionEvent){
        changeImageMove(greenRobot.getRow(), greenRobot.getCol());
        listCells[greenRobot.getRow()][greenRobot.getCol()].setOccRobot(false);
        greenRobot.goToUp(listCells);
        robotBoard.add(new ImageView(greenRobot.getRobotToken()), greenRobot.getCol(), greenRobot.getRow());
        listCells[greenRobot.getRow()][greenRobot.getCol()].setOccRobot(true);
    }
    public void greenDownArrow (ActionEvent actionEvent){
        changeImageMove(greenRobot.getRow(), greenRobot.getCol());
        listCells[greenRobot.getRow()][greenRobot.getCol()].setOccRobot(false);
        greenRobot.goToDown(listCells);
        robotBoard.add(new ImageView(greenRobot.getRobotToken()), greenRobot.getCol(), greenRobot.getRow());
        listCells[greenRobot.getRow()][greenRobot.getCol()].setOccRobot(true);
    }


    //Yellow Robot
    public void yellowRightArrow (ActionEvent actionEvent){
        changeImageMove(yellowRobot.getRow(), yellowRobot.getCol());
        listCells[yellowRobot.getRow()][yellowRobot.getCol()].setOccRobot(false);
        yellowRobot.goToRight(listCells);
        robotBoard.add(new ImageView(yellowRobot.getRobotToken()), yellowRobot.getCol(), yellowRobot.getRow());
        listCells[yellowRobot.getRow()][yellowRobot.getCol()].setOccRobot(true);
    }
    public void yellowLeftArrow (ActionEvent actionEvent){
        changeImageMove(yellowRobot.getRow(), yellowRobot.getCol());
        listCells[yellowRobot.getRow()][yellowRobot.getCol()].setOccRobot(false);
        yellowRobot.goToLeft(listCells);
        robotBoard.add(new ImageView(yellowRobot.getRobotToken()), yellowRobot.getCol(), yellowRobot.getRow());
        listCells[yellowRobot.getRow()][yellowRobot.getCol()].setOccRobot(true);
    }
    public void yellowUpArrow (ActionEvent actionEvent){
        changeImageMove(yellowRobot.getRow(), yellowRobot.getCol());
        listCells[yellowRobot.getRow()][yellowRobot.getCol()].setOccRobot(false);
        yellowRobot.goToUp(listCells);
        robotBoard.add(new ImageView(yellowRobot.getRobotToken()), yellowRobot.getCol(), yellowRobot.getRow());
        listCells[yellowRobot.getRow()][yellowRobot.getCol()].setOccRobot(true);
    }
    public void yellowDownArrow (ActionEvent actionEvent){
        changeImageMove(yellowRobot.getRow(), yellowRobot.getCol());
        listCells[yellowRobot.getRow()][yellowRobot.getCol()].setOccRobot(false);
        yellowRobot.goToDown(listCells);
        robotBoard.add(new ImageView(yellowRobot.getRobotToken()), yellowRobot.getCol(), yellowRobot.getRow());
        listCells[yellowRobot.getRow()][yellowRobot.getCol()].setOccRobot(true);
    }


}